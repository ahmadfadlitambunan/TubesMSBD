@extends('layouts.main')

@section('container')
<div class="row">
    <div class="col-xl-8 col-md-5 mx-4 ">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center">
                <h6 class="mr-auto font-weight-bold text-primary">Menambah Alat Baru</h6>
            </div>
            <div class="card-body">
                <form method="POST" action="{{ route('murid.store') }}">
                    @csrf

                    {{-- <div class="form-group">
                        <h6>Pilih Paket Kelas:</h6>
                        <div class="card">
                            <div class="card-body">
                                @foreach ($grades as $kelas)
                                <div class="form-check">
                                    <input class="form-check-input" type="radio"
                                        value="{{ old('grade_id', $kelas->id) }}" id="grade_id{{ $loop->iteration }}"
                                        name="grade_id">
                                    <label class="form-check-label" for="grade_id{{ $loop->iteration }}">{{ $kelas->name
                                        }}</label>
                                </div>
                                @endforeach
                            </div>
                        </div>
                    </div> --}}

                    <div class="form-group">
                        <label for="name">Nama</label>
                        <input type="text" class="form-control @error('name') is-invalid @enderror" id="name"
                            name="name" placeholder="Nama Equipment" value="{{ old('name') }}">
                        @error('name')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="nis">ID Equipment</label>
                        <input type="number" class="form-control @error('nis') is-invalid @enderror" id="nis" name="nis"
                            placeholder="ID Equipment" value="{{ old('nis') }}">
                        @error('nis')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="nis">Deskripsi</label>
                        <input type="number" class="form-control @error('nis') is-invalid @enderror" id="nis" name="nis"
                            placeholder="Deskripsi" value="{{ old('nis') }}">
                        @error('nis')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="nis">Gambar</label>
                        <input type="number" class="form-control @error('nis') is-invalid @enderror" id="nis" name="nis"
                            placeholder="Gambar nya blm pas" value="{{ old('nis') }}">
                        @error('nis')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror
                    </div>
                    <button type="submit" class="btn btn-primary mt-3">Tambahkan</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection